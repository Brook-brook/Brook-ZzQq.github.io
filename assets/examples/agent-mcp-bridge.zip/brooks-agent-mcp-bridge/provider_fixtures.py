"""Generated original Brook authored fixtures, never model inference.
Canonical: _includes/agent-starter/demo_offline.py, SHA256 8a0d6eabb11eda4fe8e67f0b68b8ae4d2fc5589dd26aa2a0303e18ccf7662307
"""
import json

SCENARIOS = ("distance", "batch", "forbidden", "wrong-type", "empty", "repeating")

def scripted_call(identifier, name, arguments):
    return {"type": "function_call", "id": "fc_" + identifier, "call_id": identifier,
            "name": name, "arguments": json.dumps(arguments, ensure_ascii=False), "status": "completed"}

def scripted_response(items):
    return {"id": "resp_scripted", "object": "response", "created_at": 0,
            "status": "completed", "model": "offline-fixture-model", "output": items,
            "parallel_tool_calls": True, "tools": [], "tool_choice": "auto", "metadata": {}}

def scenario_script(scenario):
    """These are authored test fixtures, never inference or an API recording."""
    if scenario not in SCENARIOS:
        raise ValueError("Choose one of the six public scripted scenarios")
    distance = scripted_call("distance_1", "measure_distance", {"from": "main-library", "to": "medical-library"})
    messages = {
        "distance": [distance],
        "batch": [distance, scripted_call("nearby_1", "nearby_places", {"center": "main-library", "radius_m": 200})],
        "forbidden": [scripted_call("forbidden_1", "publish_notes", {})],
        "wrong-type": [scripted_call("bad_type_1", "nearby_places", {"center": "main-library", "radius_m": "200"})],
        "empty": [scripted_call("empty_1", "find_places", {"query": "食堂", "category": "dining"})],
    }
    if scenario == "repeating":
        return [scripted_response([scripted_call("repeat_" + str(i), "find_places", {"query": "图书馆", "category": "library"})]) for i in range(8)]
    answer = {"type": "message", "id": "msg_scripted", "role": "assistant", "status": "completed",
              "content": [{"type": "output_text", "text": "SCRIPTED FIXTURE. Inspect the actual tool observations; no model answer or fact check was performed.", "annotations": []}]}
    return [scripted_response(messages[scenario]), scripted_response([answer])]
