"""Generated original Brook read tools; no model SDK. Do not edit this copy.
Canonical: assets/examples/agent_loop.py, SHA256 eca30647132fa855ea9151216cf73b1d468a7553422133e65c7cfcd017287255
"""
from copy import deepcopy
from datetime import date
import json
import math
import re
import unicodedata

CATEGORIES = {"all": "全部", "teaching": "教学楼", "library": "图书馆", "landscape": "校园景观", "study": "学习空间", "dining": "食堂", "housing": "宿舍区"}

RADIUS_M = 6371008.8

def text(value, limit):
    return isinstance(value, str) and bool(value.strip()) and len(value.encode("utf-16-le", errors="surrogatepass")) // 2 <= limit

def catalog_snapshot(value):
    required = {"version", "checked", "license", "attribution", "coordinateSystem", "note", "places"}
    if not isinstance(value, dict) or set(value) != required or type(value["version"]) is not int or value["version"] != 1:
        raise ValueError("Invalid catalog envelope")
    if value["license"] != "ODbL-1.0" or value["coordinateSystem"] != "WGS84" or not text(value["attribution"], 200) or not text(value["note"], 2000):
        raise ValueError("Invalid catalog provenance")
    if not isinstance(value["checked"], str) or date.fromisoformat(value["checked"]).isoformat() != value["checked"]:
        raise ValueError("Invalid source check date")
    if not isinstance(value["places"], list) or not 1 <= len(value["places"]) <= 100:
        raise ValueError("Invalid catalog size")
    seen = set()
    for p in value["places"]:
        if not isinstance(p, dict) or not isinstance(p.get("id"), str) or not re.fullmatch(r"[a-z][a-z0-9-]{0,59}", p["id"]) or p["id"] in seen:
            raise ValueError("Invalid or duplicate place ID")
        seen.add(p["id"])
        if not text(p.get("name"), 200) or not text(p.get("english"), 200) or p.get("category") not in CATEGORIES:
            raise ValueError("Invalid place metadata")
        if not isinstance(p.get("tags"), list) or not all(t in CATEGORIES for t in p["tags"]):
            raise ValueError("Invalid category tags")
        xy = p.get("coordinates")
        if not isinstance(xy, list) or len(xy) != 2 or not all(type(n) in (int, float) and math.isfinite(n) for n in xy) or not (120.06 <= xy[0] <= 120.1 and 30.29 <= xy[1] <= 30.32):
            raise ValueError("Coordinates outside this catalog's declared region")
        if not isinstance(p.get("osm"), str) or not re.fullmatch(r"(way|node)/\d+", p["osm"]):
            raise ValueError("Invalid OSM reference")
        kind, number = p["osm"].split("/")
        if p.get("source") != "https://mapcarta.com/" + ("W" if kind == "way" else "N") + number:
            raise ValueError("Invalid public source URL")
    return deepcopy(value)

def unique_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("Duplicate JSON key")
        out[key] = value
    return out

def checked_call(name, raw, catalog):
    if not isinstance(raw, str) or not text(raw, 4096):
        raise ValueError("Tool arguments must be bounded JSON text")
    def reject_constant(_):
        raise ValueError("Nonstandard numeric constant")
    args = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
    fields = {"find_places": {"query", "category"}, "measure_distance": {"from", "to"}, "nearby_places": {"center", "radius_m"}}
    if name not in fields or not isinstance(args, dict) or set(args) != fields[name]:
        raise ValueError("Tool not allowed or fields do not match")
    ids = {p["id"] for p in catalog["places"]}
    for field in ({"from", "to"} if name == "measure_distance" else {"center"} if name == "nearby_places" else set()):
        if not isinstance(args[field], str) or args[field] not in ids:
            raise ValueError("Place ID is not in the public catalog")
    if name == "find_places":
        if not text(args["query"], 80) or not isinstance(args["category"], str) or args["category"] not in CATEGORIES:
            raise ValueError("Invalid literal search or category")
        args["query"] = args["query"].strip()
    if name == "nearby_places" and (type(args["radius_m"]) not in (int, float) or not math.isfinite(args["radius_m"]) or not 0 <= args["radius_m"] <= 3000):
        raise ValueError("Radius must be a finite number between 0 and 3000 metres")
    return {"name": name, "arguments": args}

def distance(a, b):
    lon1, lat1, lon2, lat2 = map(math.radians, [*a, *b])
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * RADIUS_M * math.asin(math.sqrt(min(1, max(0, h))))

def execute_read_tool(call, catalog):
    call = checked_call(call["name"], json.dumps(call["arguments"], allow_nan=False), catalog)
    name, args, places = call["name"], call["arguments"], catalog["places"]
    def snapshot(p):
        return deepcopy({key: p[key] for key in ("id", "name", "coordinates", "osm", "source")})
    def place(identifier):
        return next(p for p in places if p["id"] == identifier)
    if name == "find_places":
        norm = lambda s: unicodedata.normalize("NFKC", s).lower()
        matches = [p for p in places if (args["category"] == "all" or args["category"] in p["tags"]) and norm(args["query"]) in norm(p["name"] + " " + p["english"] + " " + CATEGORIES[p["category"]])]
        result = {"count": len(matches), "places": [snapshot(p) for p in matches]}
    elif name == "measure_distance":
        a, b = place(args["from"]), place(args["to"])
        result = {"from": snapshot(a), "to": snapshot(b), "distance_m": distance(a["coordinates"], b["coordinates"]), "earth_radius_m": RADIUS_M}
    else:
        center = place(args["center"])
        nearby = [{**snapshot(p), "distance_m": distance(center["coordinates"], p["coordinates"])} for p in places if p["id"] != center["id"]]
        nearby = sorted((p for p in nearby if p["distance_m"] <= args["radius_m"]), key=lambda p: (p["distance_m"], p["id"]))
        result = {"center": snapshot(center), "radius_m": args["radius_m"], "count": len(nearby), "places": nearby, "earth_radius_m": RADIUS_M}
    return {"catalog_version": catalog["version"], "source_checked": catalog["checked"], "coordinate_system": catalog["coordinateSystem"], "catalog_size": len(places), "result": result}

def tool_schemas(catalog):
    ids = [p["id"] for p in catalog["places"]]
    identifier = {"type": "string", "enum": ids}
    definitions = {
        "find_places": {"query": {"type": "string", "minLength": 1, "maxLength": 80}, "category": {"type": "string", "enum": list(CATEGORIES)}},
        "measure_distance": {"from": identifier, "to": identifier},
        "nearby_places": {"center": identifier, "radius_m": {"type": "number", "minimum": 0, "maximum": 3000}},
    }
    return [{"type": "function", "name": name, "description": "Read only the provided public point catalog; no routing, source refresh or private data.", "strict": True,
             "parameters": {"type": "object", "properties": properties, "required": list(properties), "additionalProperties": False}} for name, properties in definitions.items()]
